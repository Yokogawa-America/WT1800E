#if !defined(AFX_STDAFX_H__3ABFD19B_C179_48B2_9E57_6B74B81C01AD__INCLUDED_)
#define AFX_STDAFX_H__3ABFD19B_C179_48B2_9E57_6B74B81C01AD__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#define VC_EXTRALEAN		// Windows

#include <afxwin.h>         // MFC core component
#include <afxext.h>         // MFC extantion
#include <afxdisp.h>        // MFC automation class
#include <afxdtctl.h>		// MFC Internet Explorer 4 COM control support
#ifndef _AFX_NO_AFXCMN_SUPPORT
#include <afxcmn.h>			// MFC WindowsCOM control support
#endif // _AFX_NO_AFXCMN_SUPPORT

//{{AFX_INSERT_LOCATION}}

#endif // !defined(AFX_STDAFX_H__3ABFD19B_C179_48B2_9E57_6B74B81C01AD__INCLUDED_)
